CREATE TABLE weather (
  id INT PRIMARY KEY,
  city TEXT,
  time INT,
  temp FLOAT,
  humidity FLOAT
)